to run:
1: open in intelliJ
2: press run
3: make sure the selected virtual device is running Android level 15, at least